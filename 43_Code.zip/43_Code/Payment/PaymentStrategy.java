package Payment;
public interface PaymentStrategy {
    abstract int pay();
}
