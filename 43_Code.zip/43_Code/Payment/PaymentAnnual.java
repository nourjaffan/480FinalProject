package Payment;
public class PaymentAnnual implements PaymentStrategy {
    public int pay(){
        return 20;
    }
}
