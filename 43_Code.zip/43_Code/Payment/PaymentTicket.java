package Payment;
public class PaymentTicket implements PaymentStrategy{
    public int pay(){
        return 15;
    }
}
